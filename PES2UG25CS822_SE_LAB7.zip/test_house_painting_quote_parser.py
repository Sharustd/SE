
from hypothesis import given, strategies as st

from house_painting_quote_parser import (
    clean_colour_name,
    room_area,
    total_wall_area
)


@given(st.one_of(st.text(), st.none()))
def test_clean_colour_name_no_crash(s):
    result = clean_colour_name(s)
    assert isinstance(result, str)


@given(st.one_of(st.text(), st.none()))
def test_room_area_no_crash(s):
    result = room_area(s)
    assert isinstance(result, int)


@given(st.one_of(st.text(), st.none()))
def test_total_wall_area_no_crash(s):
    result = total_wall_area(s)
    assert isinstance(result, int)
