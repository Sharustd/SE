
def clean_colour_name(name):
    """Convert a colour name into a lowercase code safely."""
    if not isinstance(name, str) or not name.strip():
        return ""

    return name.strip().lower().replace(" ", "_")


def room_area(size):
    """Calculate room area from LENGTHxWIDTH."""
    try:
        if not isinstance(size, str):
            return 0

        parts = size.lower().split("x")

        if len(parts) != 2:
            return 0

        length = float(parts[0].strip())
        width = float(parts[1].strip())

        if length <= 0 or width <= 0:
            return 0

        return int(length * width)

    except (ValueError, TypeError, OverflowError):
        return 0


def total_wall_area(areas):
    """Calculate total wall area from semicolon-separated values."""
    try:
        if not isinstance(areas, str) or not areas.strip():
            return 0

        total = 0

        for value in areas.split(";"):
            area = float(value.strip())

            if area < 0:
                return 0

            total += area

        return int(total)

    except (ValueError, TypeError, OverflowError):
        return 0
